<?php
$x=8;
$y=6.8;
$z="Strings";
var_dump($x);
var_dump($y);
var_dump($z);
?>