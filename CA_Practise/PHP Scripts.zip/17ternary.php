<?php
// Define the number
$number = 10;

// Use the ternary operator to check if the number is even or odd
$result = ($number % 2 == 0) ? "Even" : "Odd";

// Output the result
echo "The number $number is $result.";
?>