<?php

$a = 5;
$b = 10;
$c = 2;

$result = $a + $b * $c >= 20 ? $a++ : --$b + $c;
// 1. $b * $c = 10 * 2 = 20 (multiplication has higher precedence)
// 2. $a + 20 = 5 + 20 = 25 (addition)
// 3. 25 >= 20 = true (comparison)
// 4. $a++ = 5 (ternary operator selects this branch, post-increment returns value before increment)

echo "Example 1: result = \$a + \$b * \$c >= 20 ? \$a++ : --\$b + \$c -> result = $result\n"; // Output: 5


?>
