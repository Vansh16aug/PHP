<?php
// $a=10.8;
// $b=20.9;
// echo "The addition of two numbers is". $a+$b."<br>";
// echo "The subtraction of two numbers is". $a-$b."<br>";
// echo "The multiplication of two numbers is". $a*$b."<br>";
// echo "The division of two numbers is". $a/$b."<br>";
// echo "The remainder after dividing numbers is". $a%$b."<br>";
// echo "The exponent after powering numbers is". $a**$b."<br>";
// var_dump($a);
$color="red";
echo "My Car Color is $color";
echo 'My Car Color is ."$color";
?>