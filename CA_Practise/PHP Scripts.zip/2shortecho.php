<?php
$var="PHP";
echo "I love $var"."<br>";
echo 'I love'.$var."<br>"; //
//To access a variable within single quotes in PHP, you should use the concatenation operator . to combine the string with the variable.
echo "I love $var"."<br>";
?>