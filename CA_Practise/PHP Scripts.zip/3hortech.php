<?="Hello";?>
 <?php echo"Hello";